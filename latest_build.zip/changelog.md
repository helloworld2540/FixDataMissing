# 1.1 (11000)
- Add Android/media support
# 1.0 (10000)
- Initial release
- Fix Data Missing for apps