# 1.1.4 (11004)
- Show progess while action.
# 1.1.3 (11003)
- Add fix data folder support for system apps, not only user app.
# 1.1.2 (11002)
- Add module integrity verification
# 1.1.1 (11001)
- Change daemon sleep time to 30 minutes
# 1.1 (11000)
- Add Android/media support
# 1.0 (10000)
- Initial release
- Fix Data Missing for apps